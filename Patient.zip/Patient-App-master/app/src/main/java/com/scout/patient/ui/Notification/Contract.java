package com.scout.patient.ui.Notification;

public class Contract {
    interface  View{

    }
    interface  Presenter{

    }
}
