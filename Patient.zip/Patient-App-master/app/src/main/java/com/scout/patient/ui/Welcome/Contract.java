package com.scout.patient.ui.Welcome;

public class Contract {
    interface  View{

    }
    interface  Presenter{

    }
}
