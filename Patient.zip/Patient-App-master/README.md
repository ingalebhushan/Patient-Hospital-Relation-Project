This project is the related to the Medical Health of the Person’s.
With the help of this project I had developed a complete network so that long
queue in the hospitals and private clinics can be reduced. With the help of
my application Patients can book their medical appointments in advance with
their doctors ( we try to cover almost all hospitals and private clinics ). When
user book a appointment then hospital has a right to cancel or approve his
appointment in case of approved a auto-calculated time and serial number is
assigned to the patient. In this way hospital and clinics can have an online
track of their patients. Server is designed on Mongo-Db and android
application is built with Android Studio.
